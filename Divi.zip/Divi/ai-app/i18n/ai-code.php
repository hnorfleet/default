<?php

return [
	'Replace Existing Content' => esc_html__( 'Replace Existing Code', 'Divi' ),
	'Insert Code at Cursor'    => esc_html__( 'Insert Code at Cursor', 'Divi' ),
];
